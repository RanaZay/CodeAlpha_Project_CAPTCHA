let captcha;
function generate() {
  // Clear old input
  document.getElementById("submit").value = "";

  // Access the element to store the generated captcha
  captcha = document.getElementById("image");
  let uniquechar = "";

  const randomchar =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  for (let i = 1; i < 5; i++) {
    uniquechar += randomchar.charAt(Math.random() * randomchar.length);
  }

  // Store generated input
  captcha.innerHTML = uniquechar;
}

function printmsg() {
  const usr_input = document.getElementById("submit").value;

  // Check whether the input Matchs generated captcha or not
  if (usr_input == captcha.innerHTML) {
    let s = (document.getElementById("key").innerHTML = "Matched");
    // generate();
  } else {
    let s = (document.getElementById("key").innerHTML = "not Matched");
    generate();
  }
}
